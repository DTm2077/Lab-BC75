#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Runner1;
int Runner2;

int menu;
int smenu;

int DiceRoll() {
    return rand() % 6 + 1;
}

void SaveData(int position1, int position2) {
    FILE* savefile;
    savefile = fopen("savefile.txt", "w");
    fprintf(savefile, "%d/%d", position1, position2);
    fclose(savefile);
}

void LoadData(int* position1, int* position2) {
    FILE* loadfile;
    loadfile = fopen("savefile.txt", "r");
    fscanf(loadfile, "%d/%d", position1, position2);
    fclose(loadfile);
}

void printCustomBoardGame() {
    int board[151];
    for (int i = 1; i <= 150; i++) {
        board[i] = i;
    }

    int alt = 0;
    int iterLR = 151;
    int iterRL = 130;
    int val = 150;

    while (val--) { 
        if (alt == 0) { 
            iterLR--; 
            if (iterLR == Runner1) { 
                printf("R#1  "); 
            } 
            else if (iterLR == Runner2) { 
                printf("R#2  "); 
            } 
            else
                printf("%d  ", board[iterLR]); 
  
            if (iterLR % 10 == 1) { 
                printf("\n\n"); 
                alt = 1; 
                iterLR -= 10; 
            } 
        } 
        else { 
            iterRL++; 
            if (iterRL == Runner1) { 
                printf("R#1  "); 
            } 
            else if (iterRL == Runner2) { 
                printf("R#2  "); 
            } 
            else
                printf("%d  ", board[iterRL]); 
  
            if (iterRL % 10 == 0) { 
                printf("\n\n"); 
                alt = 0; 
                iterRL -= 30; 
            } 
        } 
        if (iterRL == 10) 
            break; 
    } 
    printf("\n"); 
} 

int movePlayer(int currentPlayer, int roll) 
{ 
	int newPosition = currentPlayer + roll; 
	int squarePosition[151]; 
	for (int i = 0; i <= 150; i++) { 
		squarePosition[i] = 0; 
	} 
	
    //Ladder 
	squarePosition[6] = 15;
	squarePosition[20] = 23;
	squarePosition[35] = 30;
	squarePosition[45] = 40;
	squarePosition[105] = 31;
	
	//Snake
	squarePosition[36] = -9;
	squarePosition[49] = -19;
	squarePosition[60] = -20;
	squarePosition[89] = -24;
	squarePosition[120] = -35;

    int moveSquare = newPosition + squarePosition[newPosition];

    if (moveSquare > 150) {
        return currentPlayer;
    }
    return moveSquare;
}

int main() {
    srand(time(0));
    int currentPlayer = 1;
    int winner = 0;

    printf("Welcome to Snake and Ladder Board Game!!!\n");
    printf("Rule: The position of the ladder: 6, 20, 35, 45, 75 and Snake: 14, 49, 60, 77, 98\n");

    printf("Start New Game or Load Previous Game?\n");
    printf("1.) New Game\n");
    printf("2.) Load Previous Game\n");
    scanf("%d", &menu);

    if (menu == 1) {
        Runner1 = 0;
        Runner2 = 0;
    } else if (menu == 2) {
        LoadData(&Runner1, &Runner2);
    }

    while (!winner) {
        printf("\nRunner %d, Please press Enter to roll the dice", currentPlayer);
        getchar();

        int roll = DiceRoll();
        printf("You got number %d.\n\n", roll);

        if (currentPlayer == 1) {
            Runner1 = movePlayer(Runner1, roll);
            printf("Runner 1 is now at square %d.\n\n", Runner1);
            printCustomBoardGame();
        } else {
            Runner2 = movePlayer(Runner2, roll);
            printf("Runner 2 is now at square %d.\n\n", Runner2);
            printCustomBoardGame();

            printf("Quick Save?\n");
            printf("Press 1 Yes\n");
            printf("Press 2 No\n");
            scanf("%d", &smenu);

            if (smenu == 1) {
                SaveData(Runner1, Runner2);
            }
        }

        if (Runner1 == 150) {
            printf("Congratulation! Runner 1 wins!\n");
            winner = 1;
        }

        if (Runner2 == 150) {
            printf("Congratulation! Runner 2 wins!\n");
            winner = 1;
        }

        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }

    return 0;
}
